# DockHub Automated Tests

[Português (Brasil)](./README.pt-BR.md)

DockHub uses DUnitX. This document distinguishes the current source test inventory from the current execution evidence supplied for this snapshot.

## Current structure

```text
tests/
├── Core/
│   ├── DockHub.Tests.Core.Language.Types.pas
│   └── DockHub.Tests.Core.Language.pas
├── View/
│   ├── DockHub.Tests.View.Theme.pas
│   ├── DockHub.Tests.View.Page.Composition.Base.pas
│   └── DockHub.Tests.View.Page.Main.Composition.pas
├── Runner/
│   └── DockHub.Tests.Runner.FMX.pas
├── DockHub.Tests.dpr
└── DockHub.Tests.dproj
```

## Source test inventory

The current source declares **58 tests**:

```text
TDockHubLanguageTypeTests            : 10
TDockHubLanguageTests                :  7
TDockHubThemeTests                   : 17
TDockHubPageCompositionBaseTests     : 15
TDockHubPageMainCompositionTests     :  9
                                        --
Total                                : 58
```

The current suite was executed in RAD Studio/DUnitX with the evidence supplied for this snapshot: **58 found, 58 passed, 0 ignored, 0 leaked, 0 failed and 0 errored**.

## Framework and runner

The runner uses DUnitX with three execution modes. The default developer mode is DockHub's own FMX GUI runner (`DockHub.Tests.Runner.FMX`), created entirely in code with no `.fmx` resource. With `TESTINSIGHT`, it uses `TestInsight.DUnitX`. With `CI` defined and `TESTINSIGHT` not defined, it preserves the console runner, NUnit-compatible XML logging and process exit code used for automation.

The project no longer uses `DUNitX.Loggers.GUIX` for interactive execution. In the current Delphi environment, that runner's embedded FMX resource raised `EReadError` while loading `GUIXTestRunner.FormFactor.Devices`, reporting `Invalid property value`. The local runner avoids that legacy resource dependency by constructing its UI at runtime through `CreateNew`.

The project itself remains an FMX application (`AppType=Application`). The `CI` branch explicitly switches the executable to console mode. The DockHub DPR registers NUnit XML logging and failure exit-code handling only in the CI branch; the normal branch is dedicated to the local interactive GUI runner.

The interactive runner now presents two complementary surfaces: **test selection before execution** and **result diagnosis after execution**. The selection panel exposes the DUnitX fixture/test hierarchy with checkboxes, a fixture-or-test search field, `All` / `None` / `Invert` actions, a selected-test counter, **Run selected** and **Run all** commands, plus double-click execution for a single test without changing the current selection. Fixture rows display `selected/total` counts, making partial selection visible even though FMX tree checkboxes are binary.

The result surface remains independent from execution selection: summary cards expose the counters for the last run, tests are grouped by fixture, each result combines a textual status with a semantic color and a narrow status indicator, quick filters isolate failures/errors/leaks/ignored tests, and selecting a row opens message/expected/actual/stack-trace details when those data exist. The runner owns a small private palette and does not depend on production `IDockHubTheme`, so Theme failures cannot prevent the test interface from rendering.

The runner provides **Dark** and **Light** themes, selectable from the toolbar and applied at runtime without rebuilding the suite or changing test selection. The preference is persisted only as the `Dark`/`Light` identifier in `DockHub.Tests.ini`, under the directory returned by `TPath.GetHomePath`, section `[Appearance]`, key `Theme`. **Dark** is the safe default: it is used when the file does not exist, the key is missing, the stored value is invalid, or the preference cannot be read. A persistence-write failure does not prevent the GUI from operating; on a later start the runner falls back to Dark if no valid persisted preference is available. Individual palette colors are not serialized.

Selection uses DUnitX's own runtime model. The runner builds the fixture catalog with `ITestRunner.BuildFixtures`, keeps the user's choices in the discovered `ITest.Enabled` flags, and applies the selected full test names to the execution runner before `Execute`. `Run all` ignores the current subset without altering it; `Run selected` executes only checked tests; double-click executes only that test and preserves the existing selection.

All current fixtures explicitly call `TDUnitX.RegisterTestFixture`. Explicit fixture registration is the current DockHub convention and must be preserved so every supported runner mode sees the same suite.

## Search paths

The current test project includes the source paths required by Language, Theme and the current `View.Page` architecture, including:

```text
..\src\view\Page
..\src\view\Page\Contracts
..\src\view\Page\Types
..\src\view\Page\Impl
..\src\view\Page\Impl\Main
..\modules\github_com_ricksolucoes_RickUIBuilder\src
```

The previous `..\src\view\Page\Main` / `..\src\view\Page\Main\Composition` paths are no longer part of the current test project structure.

## `TDockHubLanguageTypeTests`

Keeps the 10 existing tests for `TDockHubLanguageType` and helper conversions.

## `TDockHubLanguageTests`

Keeps 7 tests covering default/switching behavior, the Main View translation set for `pt-BR` and `en-US`, and unknown-key behavior.

The production Main translation set currently includes caption, subtitle, status labels, actions and neutral status text.

## `TDockHubThemeTests`

Keeps the existing 17 tests for the `Blue`, `Teal`, `Light` and `Dark` palettes, gradient behavior, semantic tokens and Theme transitions.

## `TDockHubPageCompositionBaseTests`

This fixture is marked:

```pascal
[Category('Contract')]
```

It validates the public lifecycle/contract of `TPageCompositionBase` without exposing its private `FState` only for testing.

The 15 source tests cover:

- nil host Form rejection;
- nil minimize callback rejection;
- nil close callback rejection;
- Build validation when Form is missing;
- Build validation when minimize callback is missing;
- Build validation when close callback is missing;
- `ApplyTheme` rejection before successful Build;
- `ApplyLanguage` rejection before successful Build;
- nil Theme rejection after Build;
- nil Language rejection after Build;
- configuration being closed after Build;
- idempotent second Build after `Built`;
- Build failure becoming terminal and blocking retry;
- common minimize/close callbacks;
- common window hover using the most recently applied Theme.

The fixture declares a test-only derived class that implements the abstract Template Method hooks. No production seam or public lifecycle-state accessor was added solely for test purposes.

## `TDockHubPageMainCompositionTests`

This fixture is marked:

```pascal
[Category('Integration')]
```

It uses a real `TForm.CreateNew(nil)` plus the current `IPageCompositionMain` / `TPageMainComposition.New` API.

The 9 source tests cover:

- centered Main card creation;
- idempotent Build without duplicate visual tree;
- `pt-BR` text application;
- `en-US` runtime change reusing existing controls;
- Theme runtime change on the Main card;
- window hover using the current Theme after runtime change;
- unimplemented administrative actions remaining disabled;
- configured minimize/close callbacks;
- host destruction while the interface keeps the composition alive until the FMX controls are destroyed.

The fixture validates observable FMX behavior and does not expose private Main Composition fields merely for test access.

## Latest executed result

The supplied DUnitX execution for the current 58-test suite reports:

```text
Tests Found   : 58
Tests Ignored : 0
Tests Passed  : 58
Tests Leaked  : 0
Tests Failed  : 0
Tests Errored : 0
```

For this snapshot, the source inventory and the executed runner result both contain 58 tests.

This result proves the runner-reported execution status above. It does not, by itself, prove code coverage, thread safety or behavior outside the executed cases.

This 58/58 evidence predates the final replacement of the interactive runner with `DockHub.Tests.Runner.FMX`. The fixtures were not changed by that correction. The code-only FMX runner itself was subsequently confirmed by the user to start and operate in the current Delphi environment; the 58/58 counts above remain the last explicitly supplied suite result until a newer execution result is provided.

## Method Toxicity — test project

A RAD Studio Method Toxicity report was supplied for `DockHub.Tests.dproj`. The highest **reported/displayed Toxicity value** in that evidence is:

```text
0.400
```

Examples at that value include:

```text
TDockHubPageCompositionBaseTests.FindLabelByText
TDockHubPageMainCompositionTests.FindLabelByText
```

Project threshold for `Toxicity`:

```text
1
```

Therefore the highest reported value in the supplied evidence is below the project threshold.

The screenshot was ordered by Toxicity; it is not used to claim project-wide maxima for `Length`, `Parameters`, `If Depth` or `Cyclomatic Complexity` beyond what is actually visible.

The Theme test refactor also groups palette assertions by cohesive areas and keeps `AssertThemePalette` as the orchestrator, reducing method toxicity without changing the tested Theme behavior.

## Running the current suite

1. Open `Dock.Hub.groupproj` or `tests/DockHub.Tests.dproj` in RAD Studio.
2. Select the `DockHub.Tests` project.
3. Select the desired configuration/platform.
4. Compile the test project.
5. Run the project normally to open `DockHub.Tests.Runner.FMX`. On first run, or whenever no valid theme preference exists, the runner starts in **Dark**.
6. Use the toolbar **Theme** selector to switch between **Dark** and **Light**. A valid choice is restored on the next start through `DockHub.Tests.ini`.
7. Use the left selection tree to check/uncheck an entire fixture or individual tests. Use the search field to locate fixtures/tests; `All`, `None` and `Invert` operate on the complete catalog, not only on currently visible search results.
8. Use **Run selected** to execute the checked subset, **Run all** to execute the complete suite without losing the current subset, or double-click a test to execute only that test while preserving the current selection.
9. Use the summary cards, fixture groups and quick result filters to navigate the result set. Select a result row to inspect status, message, comparable expected/actual values when available, and stack trace.
10. `TESTINSIGHT` remains an optional IDE-integrated runner; for automation, define `CI` and use the console/NUnit XML path.
11. Treat the actual GUI/TestInsight result or CI runner/XML result as the execution authority.

For focused diagnosis, run the Page Composition contract fixture before the Main integration fixture, then run the complete suite.

## Current coverage gaps

The current source still does not directly cover every implemented branch. Known gaps include:

- `EnUS → PtBR` fallback with a production key deliberately missing from `EnUS`;
- fallback-cache reuse in `Core.Language`;
- duplicate translation registration;
- empty translation key/value validation;
- the real unsupported-language branch;
- pixel-level visual rendering of Main;
- administrative Main actions, because their application use cases are not implemented yet.

## Maintenance rules

When behavior changes:

- test contracts and observable behavior rather than private fields;
- cover lifecycle/error transitions when they change;
- distinguish contract/unit tests from FMX integration tests;
- do not change production design merely to make a test easier;
- update `DockHub.Tests.dpr` and `.dproj` when adding a fixture;
- explicitly register each fixture with `TDUnitX.RegisterTestFixture` unless the current runner strategy is deliberately changed and revalidated;
- preserve the three runner modes (local FMX GUI, TestInsight and CI console/XML) when changing test infrastructure;
- preserve semantic result communication with both text and color; color alone must never be the only state indicator;
- preserve the separation between pre-execution selection and post-execution result filters; changing a result filter must never silently change which tests will execute;
- keep `Run all` independent from the current subset, keep `Run selected` driven by checked tests, and preserve the user's selection when a single test is executed by double-click;
- implement focused execution through DUnitX `BuildFixtures` / `ITest.Enabled` rather than a parallel test-discovery mechanism;
- keep the interactive runner independent from production Theme contracts; its private `Dark`/`Light` palettes are infrastructure-only and must not make the test runner depend on the module it may need to test;
- preserve `Dark` as the fallback when the appearance preference is missing, invalid or unreadable; persist only the theme identifier in `DockHub.Tests.ini`, never individual color tokens;
- preference read/write failures must never prevent the runner from starting or executing tests;
- do not reintroduce `DUNitX.Loggers.GUIX` without revalidating its FMX resource in the actual Delphi version; the current runner is code-only specifically to avoid `.fmx` streaming incompatibility;
- do not report a source test count as an executed/passed count;
- update execution evidence only from a real runner result; do not infer pass status from source test counts;
- apply Method Toxicity Metrics to test code as well as production code.
