unit Horse.Core.RouterTree.NextCaller;

{$IF DEFINED(FPC)}
  {$MODE DELPHI}{$H+}
{$ENDIF}

interface

uses
{$IF DEFINED(FPC)}
  Generics.Collections,
  fpHTTP,
  httpprotocol,
{$ELSE}
  Web.HTTPApp,
  System.Generics.Collections,
{$ENDIF}
  Horse.Request,
  Horse.Response,
  Horse.Callback,
  Horse.Commons;

type
  TNextCaller = class
  private
    FIndex: Integer;
    FIndexCallback: Integer;
    FSegments: TArray<THorseBufferSlice>;
    FIndexSegment: Integer;
    FHTTPType: TMethodType;
    FRequest: THorseRequest;
    FResponse: THorseResponse;
    {$IF DEFINED(FPC)}
    FMiddleware: TList<THorseCallback>;
    FCallBack: TObjectDictionary<TMethodType, TList<THorseCallback>>;
    {$ELSE}
    FMiddleware: TArray<THorseCallback>;
    FCallBack: TDictionary<TMethodType, TArray<THorseCallback>>;
    {$ENDIF}
    FCallNextPath: TCallNextPath;
    FIsGroup: Boolean;
    FTags: TArray<string>;
    FIsParamsKey: Boolean;
    FPart: string;
    FFound: ^Boolean;
  public
    procedure Configure(
      {$IF DEFINED(FPC)}
      const ACallback: TObjectDictionary<TMethodType, TList<THorseCallback>>;
      {$ELSE}
      const ACallback: TDictionary<TMethodType, TArray<THorseCallback>>;
      {$ENDIF}
      const ASegments: TArray<THorseBufferSlice>;
      AIndexSegment: Integer;
      const AHTTPType: TMethodType;
      const ARequest: THorseRequest;
      const AResponse: THorseResponse;
      const AIsGroup: Boolean;
      {$IF DEFINED(FPC)}
      const AMiddleware: TList<THorseCallback>;
      {$ELSE}
      const AMiddleware: TArray<THorseCallback>;
      {$ENDIF}
      const ATags: TArray<string>;
      const AIsParamsKey: Boolean;
      const ACallNextPath: TCallNextPath;
      const APart: string;
      var AFound: Boolean
    );
    procedure Init;
    procedure Next;
  end;

implementation

uses
{$IF DEFINED(FPC)}
  SysUtils,
{$ELSE}
  System.SysUtils,
{$ENDIF}
  Horse.Utils,
  Horse.Exception,
  Horse.Exception.Interrupted,
  Horse;



{$IF DEFINED(FPC)}
threadvar
  GCurrentNextCaller: Pointer;

procedure NextCallerDoPreValidation;
var
  LCallback: TList<THorseCallback>;
  LNextCaller: TNextCaller;
begin
  LNextCaller := TNextCaller(GCurrentNextCaller);
  try
    LNextCaller.FFound^ := True;
    if LNextCaller.FCallBack.TryGetValue(LNextCaller.FHTTPType, LCallback) then
    begin
      THorseCallbackProc(LCallback.Items[LNextCaller.FIndexCallback])(LNextCaller.FRequest, LNextCaller.FResponse, LNextCaller.Next);
    end;
  except
    on E: Exception do
    begin
      if E is EHorseCallbackInterrupted then
        raise;
      if E is EHorseException then
      begin
        LNextCaller.FResponse.Send(EHorseException(E).ToJSON).Status(EHorseException(E).Status);
        Exit;
      end;
      if THorse.HasOnError then
      begin
        THorse.ExecuteOnError(LNextCaller.FRequest, LNextCaller.FResponse, E);
        Exit;
      end;
      if LNextCaller.FResponse.Status < Integer(THTTPStatus.BadRequest) then
        LNextCaller.FResponse.Send('Internal Application Error: ' + E.Message).Status(THTTPStatus.InternalServerError);
      Exit;
    end;
  end;
  LNextCaller.Next;
end;
{$ENDIF}

procedure TNextCaller.Configure(
  {$IF DEFINED(FPC)}
  const ACallback: TObjectDictionary<TMethodType, TList<THorseCallback>>;
  {$ELSE}
  const ACallback: TDictionary<TMethodType, TArray<THorseCallback>>;
  {$ENDIF}
  const ASegments: TArray<THorseBufferSlice>;
  AIndexSegment: Integer;
  const AHTTPType: TMethodType;
  const ARequest: THorseRequest;
  const AResponse: THorseResponse;
  const AIsGroup: Boolean;
  {$IF DEFINED(FPC)}
  const AMiddleware: TList<THorseCallback>;
  {$ELSE}
  const AMiddleware: TArray<THorseCallback>;
  {$ENDIF}
  const ATags: TArray<string>;
  const AIsParamsKey: Boolean;
  const ACallNextPath: TCallNextPath;
  const APart: string;
  var AFound: Boolean
);
begin
  FCallBack := ACallback;
  FSegments := ASegments;
  FIndexSegment := AIndexSegment;
  FHTTPType := AHTTPType;
  FRequest := ARequest;
  FResponse := AResponse;
  FIsGroup := AIsGroup;
  FMiddleware := AMiddleware;
  FTags := ATags;
  FIsParamsKey := AIsParamsKey;
  FCallNextPath := ACallNextPath;
  FPart := APart;
  FFound := @AFound;
end;

procedure TNextCaller.Init;
var
  LCurrent: THorseBufferSlice;
  LCurrentStr: string;
  LTag: string;
begin
  LCurrentStr := '';
  if (not FIsGroup) and (FIndexSegment < Length(FSegments)) then
  begin
    LCurrent := FSegments[FIndexSegment];
    LCurrentStr := LCurrent.ToString;
    Inc(FIndexSegment);
  end;
  FIndex := -1;
  FIndexCallback := -1;
  if FIsParamsKey then
  begin
    for LTag in FTags do
    begin
      FRequest.Params.Dictionary.AddOrSetValue(LTag,
        FRequest.DecodePathParam(LCurrentStr));
    end;
  end;
end;

procedure TNextCaller.Next;
var
  {$IF DEFINED(FPC)}
  LCallback: TList<THorseCallback>;
  LMiddlewareCount, LCallbackCount: Integer;
  {$ELSE}
  LCallback: TArray<THorseCallback>;
  LMiddlewareCount, LCallbackCount: Integer;
  {$ENDIF}
  LKey: TMethodType;
  LAllow: string;
begin
  if FResponse.Aborted then
    Exit;
  {$IF DEFINED(FPC)}
  LMiddlewareCount := FMiddleware.Count;
  {$ELSE}
  LMiddlewareCount := Length(FMiddleware);
  {$ENDIF}

  Inc(FIndex);
  if (LMiddlewareCount > FIndex) then
  begin
    FFound^ := True;
    {$IF DEFINED(FPC)}
    THorseCallbackProc(Self.FMiddleware.Items[FIndex])(FRequest, FResponse, Next);
    LMiddlewareCount := FMiddleware.Count;
    {$ELSE}
    Self.FMiddleware[FIndex](FRequest, FResponse, Next);
    {$ENDIF}
  end
  else if (FIndexSegment = Length(FSegments)) and Assigned(FCallBack) then
  begin
    Inc(FIndexCallback);
    if FCallBack.TryGetValue(FHTTPType, LCallback) then
    begin
      {$IF DEFINED(FPC)}
      LCallbackCount := LCallback.Count;
      {$ELSE}
      LCallbackCount := Length(LCallback);
      {$ENDIF}
      if (LCallbackCount > FIndexCallback) then
      begin
        if FIndexCallback = 0 then
        begin
          {$IF DEFINED(FPC)}
          GCurrentNextCaller := Self;
          THorse.ExecutePreValidation(FRequest, FResponse, NextCallerDoPreValidation);
          {$ELSE}
          THorse.ExecutePreValidation(FRequest, FResponse,
            procedure
            begin
              try
                FFound^ := True;
                {$IF DEFINED(FPC)}
                THorseCallbackProc(LCallback.Items[FIndexCallback])(FRequest, FResponse, Next);
                {$ELSE}
                LCallback[FIndexCallback](FRequest, FResponse, Next);
                {$ENDIF}
              except
                on E: Exception do
                begin
                  if E is EHorseCallbackInterrupted then
                    raise;
                  if E is EHorseException then
                  begin
                    FResponse.Send(EHorseException(E).ToJSON).Status(EHorseException(E).Status);
                    Exit;
                  end;
                  if THorse.HasOnError then
                  begin
                    THorse.ExecuteOnError(FRequest, FResponse, E);
                    Exit;
                  end;
                  if FResponse.Status < Integer(THTTPStatus.BadRequest) then
                    FResponse.Send('Internal Application Error: ' + E.Message).Status(THTTPStatus.InternalServerError);
                  Exit;
                end;
              end;
              Next;
            end);
          {$ENDIF}
        end
        else
        begin
          try
            FFound^ := True;
            {$IF DEFINED(FPC)}
            THorseCallbackProc(LCallback.Items[FIndexCallback])(FRequest, FResponse, Next);
            {$ELSE}
            LCallback[FIndexCallback](FRequest, FResponse, Next);
            {$ENDIF}
          except
            on E: Exception do
            begin
              if E is EHorseCallbackInterrupted then
                raise;
              if E is EHorseException then
              begin
                FResponse.Send(EHorseException(E).ToJSON).Status(EHorseException(E).Status);
                Exit;
              end;
              if THorse.HasOnError then
              begin
                THorse.ExecuteOnError(FRequest, FResponse, E);
                Exit;
              end;
              if FResponse.Status < Integer(THTTPStatus.BadRequest) then
                FResponse.Send('Internal Application Error: ' + E.Message).Status(THTTPStatus.InternalServerError);
              Exit;
            end;
          end;
          Next;
        end;
      end;
    end
    else
    begin
      FFound^ := FCallNextPath(FSegments, FIndexSegment, FHTTPType, FRequest, FResponse);
      if not FFound^ then
      begin
        if FCallBack.Count > 0 then
        begin
          FFound^ := True;
          LAllow := '';
          for LKey in FCallBack.Keys do
          begin
            if LKey <> TMethodType.mtAny then
            begin
              if LAllow <> '' then
                LAllow := LAllow + ', ';
              LAllow := LAllow + UpperCase(LKey.ToString);
            end;
          end;
          if LAllow <> '' then
            FResponse.AddHeader('Allow', LAllow);
          FResponse.Send('Method Not Allowed').Status(THTTPStatus.MethodNotAllowed);
        end
        else
          FResponse.Send('Not Found').Status(THTTPStatus.NotFound);
      end;
    end;
  end
  else
  begin
    FFound^ := FCallNextPath(FSegments, FIndexSegment, FHTTPType, FRequest, FResponse);
    if (not FFound^) and (FPart = '*') and Assigned(FCallBack) and (FCallBack.ContainsKey(FHTTPType) or FCallBack.ContainsKey(TMethodType.mtAny)) then
    begin
      FIndexSegment := Length(FSegments);
      FIndexCallback := -1;
      Next;
    end;
  end;
  if not FFound^ then
    FResponse.Send('Not Found').Status(THTTPStatus.NotFound);
end;

end.
